package com.example.myapplication

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.MutableLiveData
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.myapplication.adapter.SensorAdapter
import com.example.myapplication.databinding.ActivityDashboardUserBinding
import com.example.myapplication.model.SensorModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import retrofit2.*
import retrofit2.converter.gson.GsonConverterFactory
import java.util.*
import kotlin.collections.ArrayList

class DashboardActivity : AppCompatActivity(), SensorAdapter.Listener {
    private lateinit var binding: ActivityDashboardUserBinding
    private val adapter = SensorAdapter(this, context = this)
    private val imageList = listOf(
        R.drawable.temperature,
        R.drawable.water_level,
        R.drawable.humidity,
        R.drawable.humidity,
        R.drawable.temperature,
        R.drawable.light,
        R.drawable.light,
        R.drawable.heater,
        R.drawable.food_quantity,
        R.drawable.doors,
        R.drawable.feeder,
        R.drawable.drinker,
        R.drawable.conditioner
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityDashboardUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val sharedPreference =  getSharedPreferences("PREFERENCE_NAME", Context.MODE_PRIVATE)

        binding.logoutBtn.setOnClickListener {
            val sharedPreference =  getSharedPreferences("PREFERENCE_NAME", Context.MODE_PRIVATE)
            var editor = sharedPreference.edit()
            editor.clear()
            editor.remove("username")
            editor.remove("ip")
            editor.commit()

            startActivity(Intent(this, WaitingScreenActivity::class.java))
        }

        binding.resetBtn.setOnClickListener {
            var ip = sharedPreference.getString("ip", "")
            val url = "http://" + ip + "/api/resetespapi.php"
            val queue = Volley.newRequestQueue(applicationContext)
            val request = StringRequest(Request.Method.GET, url, {
                    response ->
                Toast.makeText(applicationContext,response.toString(),Toast.LENGTH_SHORT).show()
            }, {  })
            queue.add(request)
            finish();
            startActivity(getIntent());
        }

        binding.refreshBtn.setOnClickListener {
            finish();
            startActivity(getIntent());
        }

        init()
    }

    fun JSONArray.toArrayList(): ArrayList<String> {
        val list = arrayListOf<String>()
        for (i in 0 until this.length()) {
            list.add(this.getString(i))
        }

        return list
    }

    suspend fun getLastValue(sensor_id : Int) : Double {

        val sharedPreference : SharedPreferences =  getSharedPreferences("PREFERENCE_NAME", Context.MODE_PRIVATE)
        var ip = sharedPreference.getString("ip", "")
        var value = 0.0
        val url = "http://" + ip + "/api/"

        val retrofit = Retrofit.Builder()
            .baseUrl(url)
            .addConverterFactory((GsonConverterFactory.create()))
            .build()

        val jsonPlaceHolderApi = retrofit.create(sensorLastValueInterface::class.java)

        val call  = jsonPlaceHolderApi.getData(sensor_id)

        value = call.body()?.data?.toDouble() ?: 0.0

        return value
    }

    private fun init() {
        binding.apply {
            val sharedPreference : SharedPreferences =  getSharedPreferences("PREFERENCE_NAME", Context.MODE_PRIVATE)
            var ip = sharedPreference.getString("ip", "")
            var url = "http://" + ip + "/api/sensors.php"
            val queue = Volley.newRequestQueue(applicationContext)
            val request = StringRequest(Request.Method.GET, url, {
                    response ->
                val obj = JSONObject(response)
                val data = obj.getJSONArray("data").toArrayList()
                for (sensor in data) {
                    val objs = JSONObject(sensor)
                    var sensor_id = objs.getString("sensor_id")
                    var sensor_name = objs.getString("sensor_name")
                    var sensor_type = objs.getString("sensor_type")
                    var sensor_on = objs.getString("sensor_on")
                    //var img_name = objs.getString("img_name")
                   // var sensor_value : Double = 0.0

                    GlobalScope.launch {
                        /*if(sensor_type == "SensorInt") {
                            //val sensor_value = getValue(sensor_id.toInt())
                            val sensor_value = getLastValue(sensor_id.toInt())
                        }*/

                        var sensorF = SensorModel(sensor_id.toInt(), sensor_name, sensor_type, sensor_on.toInt(), imageList[sensor_id.toInt() - 1], getLastValue(sensor_id.toInt()))
                        withContext(Dispatchers.Main) {
                            adapter.addSensor(sensorF)
                            adapter.notifyDataSetChanged()
                        }
                    }



                }
            }, {  })
            queue.add(request)

            sensorsRv.adapter = adapter
        }
    }

    override fun onClick(sensor: SensorModel) {
        val intent = Intent(this, SensorStatisticsActivity::class.java).also {
            it.putExtra("sensor", sensor.sensor_id.toString())
            startActivity(it)
        }
    }


}