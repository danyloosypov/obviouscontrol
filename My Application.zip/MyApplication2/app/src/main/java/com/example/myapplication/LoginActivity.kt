package com.example.myapplication

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.example.myapplication.databinding.ActivityLoginBinding
import org.eclipse.paho.android.service.MqttAndroidClient

class LoginActivity : AppCompatActivity(), View.OnClickListener {

    private lateinit var binding: ActivityLoginBinding

    private lateinit var etIp : EditText
    private lateinit var etUsername : EditText
    private lateinit var btnLogin : Button

    lateinit var ipAddress : String
    lateinit var username : String


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        this.etIp = findViewById<EditText>(R.id.ipEt)
        this.etUsername = findViewById<EditText>(R.id.usernameEt)
        this.btnLogin = findViewById<Button>(R.id.loginBtn)

        this.btnLogin.setOnClickListener(this)

        val sharedPreference =  getSharedPreferences("PREFERENCE_NAME", Context.MODE_PRIVATE)
        if(!(sharedPreference.getString("ip","").isNullOrEmpty() && sharedPreference.getString("username","").isNullOrEmpty())) {
            startActivity(Intent(this, DashboardActivity::class.java))
        }
    }

    override fun onClick(v: View?) {
        when(v) {
            this.btnLogin -> {
                if(!(this.etIp.text.toString().isNullOrEmpty() && this.etUsername.text.toString().isNullOrEmpty())) {
                    this.ipAddress = this.etIp.text.toString()
                    this.username = this.etUsername.text.toString()


                    val sharedPreference =  getSharedPreferences("PREFERENCE_NAME", Context.MODE_PRIVATE)
                    var editor = sharedPreference.edit()
                    editor.putString("ip", this.ipAddress)
                    editor.putString("username", this.username)
                    editor.commit()

                    binding.loginBtn.setOnClickListener {
                        startActivity(Intent(this, DashboardActivity::class.java))
                    }
                } else {
                    Toast.makeText(this, "Wrong input", Toast.LENGTH_SHORT).show()
                }


            }
        }
    }
}