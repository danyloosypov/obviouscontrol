package com.example.myapplication

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import com.android.volley.Request
import com.android.volley.Response
import com.android.volley.toolbox.JsonObjectRequest
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.myapplication.databinding.ActivitySensorStatisticsBinding
import com.github.mikephil.charting.animation.Easing
import com.github.mikephil.charting.components.AxisBase
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.ValueFormatter
import org.json.JSONArray
import org.json.JSONObject
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


class SensorStatisticsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySensorStatisticsBinding

    private var sensor_id : Int = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySensorStatisticsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val sensorId = intent.getStringExtra("sensor")
        if (sensorId != null) {
            this.sensor_id = sensorId.toInt()
        }

        binding.returnBtn.setOnClickListener {
            startActivity(Intent(this, DashboardActivity::class.java))
        }

        binding.refreshBtn.setOnClickListener {
            finish();
            startActivity(getIntent());
        }


        getLastValue()
        getData()
    }

    fun JSONArray.toArrayList(): ArrayList<String> {
        val list = arrayListOf<String>()
        for (i in 0 until this.length()) {
            list.add(this.getString(i))
        }

        return list
    }

    fun getData() {
        val sharedPreference =  getSharedPreferences("PREFERENCE_NAME", Context.MODE_PRIVATE)
        var ip = sharedPreference.getString("ip","")
        val url = "http://" + ip + "/api/sensor_statistics.php?id=" + this.sensor_id

        val queue = Volley.newRequestQueue(this)
        val request = StringRequest(Request.Method.GET, url, {
            response ->
            val obj = JSONObject(response)
            val arrayx = obj.getJSONArray("arrx")
            val arrx = arrayx.toArrayList()
            val arrayy = obj.getJSONArray("arry")
            val arry = arrayy.toArrayList()
            var index = 0
            val entries = ArrayList<Entry>()
            val numMap: HashMap<Float, String> = HashMap()
            for (value in arrx) {
                numMap.put(arry.get(index).toFloat(), arrx.get(index))
                entries.add(Entry(index.toFloat(), arry.get(index).toFloat()))
                index++;
            }

            val vl = LineDataSet(entries, "My Type")
//Part4
            vl.setDrawValues(false)
            vl.setDrawFilled(true)
            vl.lineWidth = 3f
            vl.fillColor = R.color.black
            vl.fillAlpha = R.color.purple_500
//Part5
            binding.lineChart.xAxis.labelRotationAngle = 0f
//Part6
            binding.lineChart.data = LineData(vl)
//Part7
            binding.lineChart.axisRight.isEnabled = false
            binding.lineChart.xAxis.axisMaximum = index.toFloat()
//Part8
            binding.lineChart.setTouchEnabled(true)
            binding.lineChart.setPinchZoom(true)
//Part9
            binding.lineChart.description.text = "Days"
            binding.lineChart.setNoDataText("No forex yet!")
//Part10
            binding.lineChart.animateX(1800, Easing.EaseInExpo)
        }, {  })
        queue.add(request)


    }

    fun getLastValue() {
        val sharedPreference : SharedPreferences =  getSharedPreferences("PREFERENCE_NAME", Context.MODE_PRIVATE)
        var ip = sharedPreference.getString("ip", "")
        var value = 0.0
        val url = "http://" + ip + "/api/sensorlastvalue.php?id=" + sensor_id
        val queue = Volley.newRequestQueue(applicationContext)

        val request = JsonObjectRequest(Request.Method.GET, url, null, Response.Listener {
            response ->
            val answer = response.getString("data")
            binding.currentValue.text = answer
        }, Response.ErrorListener {  })
        queue.add(request)
    }



}