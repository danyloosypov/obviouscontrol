package com.example.myapplication

import com.google.gson.annotations.SerializedName

data class sensorLastValue(
    //@SerializedName("data")
    val `data`: String
)