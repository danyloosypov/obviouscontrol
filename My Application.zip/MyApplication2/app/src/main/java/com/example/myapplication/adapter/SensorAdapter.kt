package com.example.myapplication.adapter

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.myapplication.DashboardActivity
import com.example.myapplication.R
import com.example.myapplication.databinding.SensorControlBinding
import com.example.myapplication.model.SensorModel
import com.github.mikephil.charting.animation.Easing
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import org.json.JSONObject

class SensorAdapter(val listener: Listener,  val context: Context) : RecyclerView.Adapter<SensorAdapter.SensorViewHolder>() {

    val sensorList = ArrayList<SensorModel>()

    class SensorViewHolder(val context: Context, view : View) : RecyclerView.ViewHolder(view) {

        val binding = SensorControlBinding.bind(view)

        fun bind(sensor: SensorModel, listener: Listener) = with(binding) {
            sensorIcon.setImageResource(sensor.sensor_img)
            sensorName.text = sensor.sensor_name
            if (sensor.sensor_type == "CmdInt") {
                sensorValue.text = ""
                moreBtn.visibility = View.GONE
                switchOn.visibility = View.VISIBLE
                if(sensor.sensor_on == 1) {
                    switchOn.isChecked = true
                }
            } else {
                moreBtn.visibility = View.VISIBLE
                switchOn.visibility = View.INVISIBLE
                sensorValue.text = ""
                sensorValue.text = sensor.sensor_value.toString()
            }


            switchOn.setOnCheckedChangeListener { buttonView, isChecked ->
                val sharedPreference : SharedPreferences =  context.getSharedPreferences("PREFERENCE_NAME", Context.MODE_PRIVATE)
                var ip = sharedPreference.getString("ip","")

                if (isChecked) {
                    switchOn.text = "On"
                    println("sensorId is on " + sensor.sensor_id)
                    val url = "http://" + ip + "/api/sensorcontrollerapi.php?idon=" + sensor.sensor_id

                    val queue = Volley.newRequestQueue(context)
                    val request = StringRequest(Request.Method.GET, url, {
                            response ->
                            Log.e("Erroe", response.toString())
                    }, {  })
                    queue.add(request)
                } else {
                    switchOn.text = "Off"
                    println("sensorId is off " + sensor.sensor_id)
                    val url = "http://" + ip + "/api/sensorcontrollerapi.php?idoff=" + sensor.sensor_id

                    val queue = Volley.newRequestQueue(context)
                    val request = StringRequest(Request.Method.GET, url, {
                            response ->
                        Log.e("Erroe", response.toString())
                    }, {  })
                    queue.add(request)
                }
            }

            moreBtn.setOnClickListener {
                listener.onClick(sensor)
            }
        }

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SensorViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.sensor_control, parent, false)
        return SensorViewHolder(context, view)

    }

    override fun onBindViewHolder(holder: SensorViewHolder, position: Int) {
        holder.bind(sensorList[position], listener)
    }

    override fun getItemCount(): Int {
        return sensorList.size
    }

    fun addSensor(sensor: SensorModel) {
        sensorList.add(sensor)
        notifyDataSetChanged()
    }

    interface Listener {
        fun onClick(sensor: SensorModel)
    }

}