package com.example.myapplication.model

class SensorModel (
    var sensor_id : Int,
    val sensor_name : String,
    val sensor_type : String,
    val sensor_on : Int,
    val sensor_img : Int,
    var sensor_value : Double

)